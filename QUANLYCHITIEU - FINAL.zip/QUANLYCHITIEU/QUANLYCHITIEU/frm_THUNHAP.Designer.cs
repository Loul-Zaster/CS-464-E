﻿namespace QUANLYCHITIEU
{
    partial class frm_THUNHAP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_money = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_note = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.date_them = new System.Windows.Forms.DateTimePicker();
            this.thuNhapBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.thuNhapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_save = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_fix = new System.Windows.Forms.Button();
            this.thuNhapBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataChungDataSet = new QUANLYCHITIEU.DataChungDataSet();
            this.thuNhapBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.thuNhapTableAdapter = new QUANLYCHITIEU.DataChungDataSetTableAdapters.ThuNhapTableAdapter();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_mgd = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thuNhapBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.dataChungDataSet1 = new QUANLYCHITIEU.DataChungDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(77, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(398, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "THU NHẬP CÁ NHÂN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(112, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Số Tiền:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 441);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "GHI CHÚ";
            // 
            // txt_money
            // 
            this.txt_money.Location = new System.Drawing.Point(117, 249);
            this.txt_money.Name = "txt_money";
            this.txt_money.Size = new System.Drawing.Size(300, 31);
            this.txt_money.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 563);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "GHI CHÚ";
            // 
            // txt_note
            // 
            this.txt_note.Location = new System.Drawing.Point(117, 500);
            this.txt_note.Multiline = true;
            this.txt_note.Name = "txt_note";
            this.txt_note.Size = new System.Drawing.Size(300, 256);
            this.txt_note.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Location = new System.Drawing.Point(686, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(381, 45);
            this.label5.TabIndex = 0;
            this.label5.Text = "LỊCH SỬ THU NHẬP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(112, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "Ngày:";
            // 
            // date_them
            // 
            this.date_them.CustomFormat = "dd/MM/yyyy";
            this.date_them.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.date_them.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_them.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_them.Location = new System.Drawing.Point(117, 371);
            this.date_them.Name = "date_them";
            this.date_them.Size = new System.Drawing.Size(300, 33);
            this.date_them.TabIndex = 3;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkRed;
            this.btn_save.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_save.Location = new System.Drawing.Point(170, 792);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(189, 88);
            this.btn_save.TabIndex = 5;
            this.btn_save.Text = "Lưu";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkRed;
            this.button1.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(986, 792);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 88);
            this.button1.TabIndex = 5;
            this.button1.Text = "Xóa";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_fix
            // 
            this.btn_fix.BackColor = System.Drawing.Color.DarkRed;
            this.btn_fix.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fix.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_fix.Location = new System.Drawing.Point(585, 792);
            this.btn_fix.Name = "btn_fix";
            this.btn_fix.Size = new System.Drawing.Size(189, 88);
            this.btn_fix.TabIndex = 5;
            this.btn_fix.Text = "Sửa";
            this.btn_fix.UseVisualStyleBackColor = false;
            this.btn_fix.Click += new System.EventHandler(this.btn_fix_Click);
            // 
            // thuNhapBindingSource3
            // 
            this.thuNhapBindingSource3.DataMember = "ThuNhap";
            this.thuNhapBindingSource3.DataSource = this.dataChungDataSet;
            // 
            // dataChungDataSet
            // 
            this.dataChungDataSet.DataSetName = "DataChungDataSet";
            this.dataChungDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // thuNhapBindingSource2
            // 
            this.thuNhapBindingSource2.DataMember = "ThuNhap";
            // 
            // thuNhapTableAdapter
            // 
            this.thuNhapTableAdapter.ClearBeforeFill = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(836, 792);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "Mã GD:";
            this.label7.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt_mgd
            // 
            this.txt_mgd.Location = new System.Drawing.Point(851, 828);
            this.txt_mgd.Name = "txt_mgd";
            this.txt_mgd.Size = new System.Drawing.Size(55, 31);
            this.txt_mgd.TabIndex = 7;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataGridView1.DataSource = this.thuNhapBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(530, 196);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(677, 559);
            this.dataGridView1.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "matn";
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Mã GD";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "sotien";
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "Số Tiền";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ngaynhan";
            this.dataGridViewTextBoxColumn6.HeaderText = "Ngày Nhận";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 80;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ghichu";
            this.dataGridViewTextBoxColumn7.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 240;
            // 
            // thuNhapBindingSource4
            // 
            this.thuNhapBindingSource4.DataMember = "ThuNhap";
            this.thuNhapBindingSource4.DataSource = this.dataChungDataSet1;
            // 
            // dataChungDataSet1
            // 
            this.dataChungDataSet1.DataSetName = "DataChungDataSet";
            this.dataChungDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // frm_THUNHAP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1470, 1093);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_mgd);
            this.Controls.Add(this.btn_fix);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.date_them);
            this.Controls.Add(this.txt_note);
            this.Controls.Add(this.txt_money);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Name = "frm_THUNHAP";
            this.Text = "THÊM THU NHẬP";
            this.Load += new System.EventHandler(this.frm_THUNHAP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuNhapBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_money;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_note;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker date_them;
        
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_fix;
        private System.Windows.Forms.DataGridViewTextBoxColumn sotienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaynhanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichuDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource thuNhapBindingSource;
        private System.Windows.Forms.BindingSource thuNhapBindingSource1;
        private System.Windows.Forms.BindingSource thuNhapBindingSource2;
        private System.Windows.Forms.DataGridViewTextBoxColumn matnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataChungDataSet dataChungDataSet;
        private System.Windows.Forms.BindingSource thuNhapBindingSource3;
        private DataChungDataSetTableAdapters.ThuNhapTableAdapter thuNhapTableAdapter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_mgd;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataChungDataSet dataChungDataSet1;
        private System.Windows.Forms.BindingSource thuNhapBindingSource4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}