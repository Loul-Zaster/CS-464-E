﻿namespace QUANLYCHITIEU
{
    partial class frm_CHITIEU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_tenCT = new System.Windows.Forms.TextBox();
            this.txt_sl = new System.Windows.Forms.TextBox();
            this.txt_sotien = new System.Windows.Forms.TextBox();
            this.cbb_danhmuc = new System.Windows.Forms.ComboBox();
            this.danhMucBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataChungDataSet1 = new QUANLYCHITIEU.DataChungDataSet1();
            this.btn_them = new System.Windows.Forms.Button();
            this.btn_xoa = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_ghichu = new System.Windows.Forms.TextBox();
            this.danhMucTableAdapter = new QUANLYCHITIEU.DataChungDataSet1TableAdapters.DanhMucTableAdapter();
            this.dataChiTieuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chiTieuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngaychiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chiTieuBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataChungDataSet2 = new QUANLYCHITIEU.DataChungDataSet2();
            this.chiTieuBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.chiTieuBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.btn_luu = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_mact = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chiTieuTableAdapter = new QUANLYCHITIEU.DataChungDataSet2TableAdapters.ChiTieuTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.date_chitieu = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.danhMucBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChiTieuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(80, 79);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(424, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tên Mặt Hàng/Loại Chi Tiêu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(80, 190);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Số Lượng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(80, 302);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 35);
            this.label3.TabIndex = 1;
            this.label3.Text = "Số Tiền";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(80, 415);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 35);
            this.label4.TabIndex = 1;
            this.label4.Text = "Danh Mục";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Location = new System.Drawing.Point(632, 79);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 35);
            this.label5.TabIndex = 1;
            this.label5.Text = "Thông Tin";
            // 
            // txt_tenCT
            // 
            this.txt_tenCT.Location = new System.Drawing.Point(86, 137);
            this.txt_tenCT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tenCT.Name = "txt_tenCT";
            this.txt_tenCT.Size = new System.Drawing.Size(418, 31);
            this.txt_tenCT.TabIndex = 2;
            // 
            // txt_sl
            // 
            this.txt_sl.Location = new System.Drawing.Point(86, 248);
            this.txt_sl.Margin = new System.Windows.Forms.Padding(4);
            this.txt_sl.Name = "txt_sl";
            this.txt_sl.Size = new System.Drawing.Size(144, 31);
            this.txt_sl.TabIndex = 2;
            // 
            // txt_sotien
            // 
            this.txt_sotien.Location = new System.Drawing.Point(86, 362);
            this.txt_sotien.Margin = new System.Windows.Forms.Padding(4);
            this.txt_sotien.Name = "txt_sotien";
            this.txt_sotien.Size = new System.Drawing.Size(418, 31);
            this.txt_sotien.TabIndex = 2;
            // 
            // cbb_danhmuc
            // 
            this.cbb_danhmuc.DataSource = this.danhMucBindingSource;
            this.cbb_danhmuc.FormattingEnabled = true;
            this.cbb_danhmuc.Location = new System.Drawing.Point(86, 481);
            this.cbb_danhmuc.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_danhmuc.Name = "cbb_danhmuc";
            this.cbb_danhmuc.Size = new System.Drawing.Size(418, 33);
            this.cbb_danhmuc.TabIndex = 4;
            // 
            // danhMucBindingSource
            // 
            this.danhMucBindingSource.DataMember = "DanhMuc";
            this.danhMucBindingSource.DataSource = this.dataChungDataSet1;
            // 
            // dataChungDataSet1
            // 
            this.dataChungDataSet1.DataSetName = "DataChungDataSet1";
            this.dataChungDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_them
            // 
            this.btn_them.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_them.Location = new System.Drawing.Point(86, 544);
            this.btn_them.Margin = new System.Windows.Forms.Padding(4);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(222, 60);
            this.btn_them.TabIndex = 5;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = true;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // btn_xoa
            // 
            this.btn_xoa.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_xoa.Location = new System.Drawing.Point(338, 544);
            this.btn_xoa.Margin = new System.Windows.Forms.Padding(4);
            this.btn_xoa.Name = "btn_xoa";
            this.btn_xoa.Size = new System.Drawing.Size(166, 60);
            this.btn_xoa.TabIndex = 5;
            this.btn_xoa.Text = "Xóa";
            this.btn_xoa.UseVisualStyleBackColor = true;
            this.btn_xoa.Click += new System.EventHandler(this.btn_xoa_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkRed;
            this.label6.Location = new System.Drawing.Point(80, 638);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 35);
            this.label6.TabIndex = 1;
            this.label6.Text = "Ghi Chú";
            // 
            // txt_ghichu
            // 
            this.txt_ghichu.Location = new System.Drawing.Point(86, 696);
            this.txt_ghichu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ghichu.Multiline = true;
            this.txt_ghichu.Name = "txt_ghichu";
            this.txt_ghichu.Size = new System.Drawing.Size(418, 175);
            this.txt_ghichu.TabIndex = 6;
            // 
            // danhMucTableAdapter
            // 
            this.danhMucTableAdapter.ClearBeforeFill = true;
            // 
            // chiTieuBindingSource
            // 
            this.chiTieuBindingSource.DataMember = "ChiTieu";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.ngaychiDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView1.DataSource = this.chiTieuBindingSource3;
            this.dataGridView1.Location = new System.Drawing.Point(640, 137);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(844, 735);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "maCT";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã Chi Tiêu";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "tenCT";
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên Chi Tiêu";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "soluong";
            this.dataGridViewTextBoxColumn3.HeaderText = "Số Lượng";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 50;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "sotien";
            this.dataGridViewTextBoxColumn4.HeaderText = "Số Tiền";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "MaDM";
            this.dataGridViewTextBoxColumn5.HeaderText = "Danh Mục";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 50;
            // 
            // ngaychiDataGridViewTextBoxColumn
            // 
            this.ngaychiDataGridViewTextBoxColumn.DataPropertyName = "ngaychi";
            this.ngaychiDataGridViewTextBoxColumn.HeaderText = "Ngày Chi Tiêu";
            this.ngaychiDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.ngaychiDataGridViewTextBoxColumn.Name = "ngaychiDataGridViewTextBoxColumn";
            this.ngaychiDataGridViewTextBoxColumn.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ghichu";
            this.dataGridViewTextBoxColumn6.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 200;
            // 
            // chiTieuBindingSource3
            // 
            this.chiTieuBindingSource3.DataMember = "ChiTieu";
            this.chiTieuBindingSource3.DataSource = this.dataChungDataSet2;
            // 
            // dataChungDataSet2
            // 
            this.dataChungDataSet2.DataSetName = "DataChungDataSet2";
            this.dataChungDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chiTieuBindingSource1
            // 
            this.chiTieuBindingSource1.DataMember = "ChiTieu";
            // 
            // chiTieuBindingSource2
            // 
            this.chiTieuBindingSource2.DataMember = "ChiTieu";
            // 
            // btn_luu
            // 
            this.btn_luu.BackColor = System.Drawing.Color.DarkRed;
            this.btn_luu.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_luu.Location = new System.Drawing.Point(196, 931);
            this.btn_luu.Margin = new System.Windows.Forms.Padding(6);
            this.btn_luu.Name = "btn_luu";
            this.btn_luu.Size = new System.Drawing.Size(186, 108);
            this.btn_luu.TabIndex = 8;
            this.btn_luu.Text = "LƯU";
            this.btn_luu.UseVisualStyleBackColor = false;
            this.btn_luu.Click += new System.EventHandler(this.btn_luu_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkRed;
            this.btn_delete.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_delete.Location = new System.Drawing.Point(1090, 921);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(6);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(186, 108);
            this.btn_delete.TabIndex = 8;
            this.btn_delete.Text = "XÓA";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txt_mact
            // 
            this.txt_mact.Location = new System.Drawing.Point(996, 956);
            this.txt_mact.Margin = new System.Windows.Forms.Padding(6);
            this.txt_mact.Name = "txt_mact";
            this.txt_mact.Size = new System.Drawing.Size(58, 31);
            this.txt_mact.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(850, 962);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Mã Chi Tiêu:";
            // 
            // chiTieuTableAdapter
            // 
            this.chiTieuTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkRed;
            this.label8.Location = new System.Drawing.Point(270, 190);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 35);
            this.label8.TabIndex = 1;
            this.label8.Text = "Ngày";
            // 
            // date_chitieu
            // 
            this.date_chitieu.CustomFormat = "dd/MM/yyyy";
            this.date_chitieu.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_chitieu.Location = new System.Drawing.Point(276, 248);
            this.date_chitieu.Margin = new System.Windows.Forms.Padding(6);
            this.date_chitieu.Name = "date_chitieu";
            this.date_chitieu.Size = new System.Drawing.Size(228, 31);
            this.date_chitieu.TabIndex = 11;
            // 
            // frm_CHITIEU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1826, 1262);
            this.Controls.Add(this.date_chitieu);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_mact);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_luu);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_ghichu);
            this.Controls.Add(this.btn_xoa);
            this.Controls.Add(this.btn_them);
            this.Controls.Add(this.cbb_danhmuc);
            this.Controls.Add(this.txt_sotien);
            this.Controls.Add(this.txt_sl);
            this.Controls.Add(this.txt_tenCT);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_CHITIEU";
            this.Text = "BẢNG CHI TIÊU";
            this.Load += new System.EventHandler(this.frm_CHITIEU_Load);
            ((System.ComponentModel.ISupportInitialize)(this.danhMucBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChiTieuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiTieuBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_tenCT;
        private System.Windows.Forms.TextBox txt_sl;
        private System.Windows.Forms.TextBox txt_sotien;
        private System.Windows.Forms.ComboBox cbb_danhmuc;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.Button btn_xoa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_ghichu;
        private DataChungDataSet1 dataChungDataSet1;
        private System.Windows.Forms.BindingSource danhMucBindingSource;
        private DataChungDataSet1TableAdapters.DanhMucTableAdapter danhMucTableAdapter;
        private System.Windows.Forms.BindingSource dataChiTieuBindingSource;
        private System.Windows.Forms.BindingSource chiTieuBindingSource;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource chiTieuBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn maCTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenCTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soluongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sotienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maDMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichuDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource chiTieuBindingSource2;
        private System.Windows.Forms.Button btn_luu;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_mact;
        private System.Windows.Forms.Label label7;
        private DataChungDataSet2 dataChungDataSet2;
        private System.Windows.Forms.BindingSource chiTieuBindingSource3;
        private DataChungDataSet2TableAdapters.ChiTieuTableAdapter chiTieuTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaychiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker date_chitieu;
    }
}