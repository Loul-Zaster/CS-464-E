﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_CHART : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_CHART()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void LoadChart()
        {
            string sqlThu = "SELECT MONTH(ngaynhan) AS Thang, SUM(CAST(sotien AS INT)) AS TongThu FROM ThuNhap GROUP BY MONTH(ngaynhan)";
            string sqlChi = "SELECT MONTH(ngaychi) AS Thang, SUM(CAST(sotien AS INT)) AS TongChi FROM ChiTieu GROUP BY MONTH(ngaychi)";

            DataTable dtThu = lopchung.LoadDL(sqlThu); // Thu nhập
            DataTable dtChi = lopchung.LoadDL(sqlChi); // Chi tiêu

            // Xóa dữ liệu cũ trong biểu đồ
            chartChiTieu.Series.Clear();

            // Thêm Series cho Thu nhập
            chartChiTieu.Series.Add("Thu nhập");
            chartChiTieu.Series["Thu nhập"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
            chartChiTieu.Series["Thu nhập"].Color = Color.Green;

            // Thêm Series cho Chi tiêu
            chartChiTieu.Series.Add("Chi tiêu");
            chartChiTieu.Series["Chi tiêu"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
            chartChiTieu.Series["Chi tiêu"].Color = Color.Red;

            // Ghi dữ liệu vào biểu đồ cho Thu nhập
            foreach (DataRow row in dtThu.Rows)
            {
                string thang = "Tháng " + row["Thang"].ToString();
                int tongThu = Convert.ToInt32(row["TongThu"]);
                chartChiTieu.Series["Thu nhập"].Points.AddXY(thang, tongThu);
            }

            // Ghi dữ liệu vào biểu đồ cho Chi tiêu
            foreach (DataRow row in dtChi.Rows)
            {
                string thang = "Tháng " + row["Thang"].ToString();
                int tongChi = Convert.ToInt32(row["TongChi"]);
                chartChiTieu.Series["Chi tiêu"].Points.AddXY(thang, tongChi);
            }

            // Thiết lập trục x và y
            chartChiTieu.ChartAreas[0].AxisX.Title = "Tháng";
            chartChiTieu.ChartAreas[0].AxisY.Title = "Số tiền";
        }
        private void frm_CHART_Load(object sender, EventArgs e)
        {
            LoadChart();
        }
    }
}
