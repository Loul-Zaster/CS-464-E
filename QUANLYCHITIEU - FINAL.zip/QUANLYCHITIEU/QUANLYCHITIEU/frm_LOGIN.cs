﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_LOGIN : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_LOGIN()
        {
            InitializeComponent();
        }

        private void frm_LOGIN_Load(object sender, EventArgs e)
        {

        }

        private void btn_EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_LOGIN_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "SELECT * FROM DangNhap WHERE username = '" + txt_login.Text + "' AND password ='" + txt_pass.Text + "' ";
                if (lopchung.LoadDL(sql).Rows.Count > 0)
                {
                    frm_HOME home = new frm_HOME();
                    home.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản hoặc mật khẩu, vui lòng thử lại", "Không thể đăng nhập", MessageBoxButtons.OK);
                    txt_login.Clear();
                    txt_pass.Clear();
                }
            }
            catch
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu, vui lòng thử lại", "Không thể đăng nhập", MessageBoxButtons.OK);
            }
        }

        private void ck_mk_CheckedChanged(object sender, EventArgs e)
        {
            if (ck_mk.Checked == true)
                txt_pass.UseSystemPasswordChar = false;
            else txt_pass.UseSystemPasswordChar = true;
        }
    }
}
