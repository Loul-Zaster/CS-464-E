﻿namespace QUANLYCHITIEU
{
    partial class frm_BAOCAOTHUCHI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.data_thuchi = new System.Windows.Forms.DataGridView();
            this.soTienDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loaiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngayThangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ghiChuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tongHopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataChungDataSet3 = new QUANLYCHITIEU.DataChungDataSet3();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tongHopTableAdapter = new QUANLYCHITIEU.DataChungDataSet3TableAdapters.TongHopTableAdapter();
            this.lbl_thu = new System.Windows.Forms.Label();
            this.lbl_chi = new System.Windows.Forms.Label();
            this.btn_reload = new System.Windows.Forms.Button();
            this.btn_pdf = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_thuchi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tongHopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(415, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "BẢNG THU CHI";
            // 
            // data_thuchi
            // 
            this.data_thuchi.AutoGenerateColumns = false;
            this.data_thuchi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_thuchi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.soTienDataGridViewTextBoxColumn,
            this.loaiDataGridViewTextBoxColumn,
            this.ngayThangDataGridViewTextBoxColumn,
            this.ghiChuDataGridViewTextBoxColumn});
            this.data_thuchi.DataSource = this.tongHopBindingSource;
            this.data_thuchi.Location = new System.Drawing.Point(102, 204);
            this.data_thuchi.Name = "data_thuchi";
            this.data_thuchi.RowHeadersVisible = false;
            this.data_thuchi.RowHeadersWidth = 82;
            this.data_thuchi.RowTemplate.Height = 33;
            this.data_thuchi.Size = new System.Drawing.Size(952, 384);
            this.data_thuchi.TabIndex = 1;
            this.data_thuchi.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // soTienDataGridViewTextBoxColumn
            // 
            this.soTienDataGridViewTextBoxColumn.DataPropertyName = "SoTien";
            this.soTienDataGridViewTextBoxColumn.HeaderText = "Số Tiền";
            this.soTienDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.soTienDataGridViewTextBoxColumn.Name = "soTienDataGridViewTextBoxColumn";
            this.soTienDataGridViewTextBoxColumn.Width = 90;
            // 
            // loaiDataGridViewTextBoxColumn
            // 
            this.loaiDataGridViewTextBoxColumn.DataPropertyName = "Loai";
            this.loaiDataGridViewTextBoxColumn.HeaderText = "Loại Tiền";
            this.loaiDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.loaiDataGridViewTextBoxColumn.Name = "loaiDataGridViewTextBoxColumn";
            this.loaiDataGridViewTextBoxColumn.Width = 90;
            // 
            // ngayThangDataGridViewTextBoxColumn
            // 
            this.ngayThangDataGridViewTextBoxColumn.DataPropertyName = "NgayThang";
            this.ngayThangDataGridViewTextBoxColumn.HeaderText = "Ngày Tháng";
            this.ngayThangDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.ngayThangDataGridViewTextBoxColumn.Name = "ngayThangDataGridViewTextBoxColumn";
            this.ngayThangDataGridViewTextBoxColumn.Width = 200;
            // 
            // ghiChuDataGridViewTextBoxColumn
            // 
            this.ghiChuDataGridViewTextBoxColumn.DataPropertyName = "GhiChu";
            this.ghiChuDataGridViewTextBoxColumn.HeaderText = "Ghi Chú";
            this.ghiChuDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.ghiChuDataGridViewTextBoxColumn.Name = "ghiChuDataGridViewTextBoxColumn";
            this.ghiChuDataGridViewTextBoxColumn.Width = 200;
            // 
            // tongHopBindingSource
            // 
            this.tongHopBindingSource.DataMember = "TongHop";
            this.tongHopBindingSource.DataSource = this.dataChungDataSet3;
            // 
            // dataChungDataSet3
            // 
            this.dataChungDataSet3.DataSetName = "DataChungDataSet3";
            this.dataChungDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(1078, 307);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bạn đã thu vào:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(1078, 426);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Bạn đã chi tiêu:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1518, 303);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "vnd";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1518, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 29);
            this.label5.TabIndex = 0;
            this.label5.Text = "vnd";
            // 
            // tongHopTableAdapter
            // 
            this.tongHopTableAdapter.ClearBeforeFill = true;
            // 
            // lbl_thu
            // 
            this.lbl_thu.AutoSize = true;
            this.lbl_thu.Font = new System.Drawing.Font("Tahoma", 10.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_thu.Location = new System.Drawing.Point(1295, 303);
            this.lbl_thu.Name = "lbl_thu";
            this.lbl_thu.Size = new System.Drawing.Size(175, 33);
            this.lbl_thu.TabIndex = 2;
            this.lbl_thu.Text = "                    ";
            // 
            // lbl_chi
            // 
            this.lbl_chi.AutoSize = true;
            this.lbl_chi.Font = new System.Drawing.Font("Tahoma", 10.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chi.Location = new System.Drawing.Point(1295, 422);
            this.lbl_chi.Name = "lbl_chi";
            this.lbl_chi.Size = new System.Drawing.Size(175, 33);
            this.lbl_chi.TabIndex = 2;
            this.lbl_chi.Text = "                    ";
            // 
            // btn_reload
            // 
            this.btn_reload.BackColor = System.Drawing.Color.DarkRed;
            this.btn_reload.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reload.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_reload.Location = new System.Drawing.Point(503, 613);
            this.btn_reload.Name = "btn_reload";
            this.btn_reload.Size = new System.Drawing.Size(157, 69);
            this.btn_reload.TabIndex = 3;
            this.btn_reload.Text = "Reload";
            this.btn_reload.UseVisualStyleBackColor = false;
            this.btn_reload.Click += new System.EventHandler(this.btn_reload_Click);
            // 
            // btn_pdf
            // 
            this.btn_pdf.BackColor = System.Drawing.Color.DarkRed;
            this.btn_pdf.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pdf.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_pdf.Location = new System.Drawing.Point(1443, 613);
            this.btn_pdf.Name = "btn_pdf";
            this.btn_pdf.Size = new System.Drawing.Size(141, 69);
            this.btn_pdf.TabIndex = 4;
            this.btn_pdf.Text = "In Sao Kê";
            this.btn_pdf.UseVisualStyleBackColor = false;
            this.btn_pdf.Click += new System.EventHandler(this.button1_Click);
            // 
            // frm_BAOCAOTHUCHI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1749, 802);
            this.Controls.Add(this.btn_pdf);
            this.Controls.Add(this.btn_reload);
            this.Controls.Add(this.lbl_chi);
            this.Controls.Add(this.lbl_thu);
            this.Controls.Add(this.data_thuchi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_BAOCAOTHUCHI";
            this.Text = "BÁO CÁO THU CHI";
            this.Load += new System.EventHandler(this.frm_BAOCAOTHUCHI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data_thuchi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tongHopBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataChungDataSet3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView data_thuchi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private DataChungDataSet3 dataChungDataSet3;
        private System.Windows.Forms.BindingSource tongHopBindingSource;
        private DataChungDataSet3TableAdapters.TongHopTableAdapter tongHopTableAdapter;
        private System.Windows.Forms.Label lbl_thu;
        private System.Windows.Forms.Label lbl_chi;
        private System.Windows.Forms.DataGridViewTextBoxColumn soTienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngayThangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghiChuDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_reload;
        private System.Windows.Forms.Button btn_pdf;
    }
}