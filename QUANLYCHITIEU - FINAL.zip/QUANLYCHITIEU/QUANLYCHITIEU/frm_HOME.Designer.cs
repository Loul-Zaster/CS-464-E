﻿namespace QUANLYCHITIEU
{
    partial class frm_HOME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_HOME));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tạoKhoảnChiTiêuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmChiTiêuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoThuChiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHÔNGTINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.biểuĐồThuChiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.tHÔNGTINToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1494, 45);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tạoKhoảnChiTiêuToolStripMenuItem,
            this.thêmChiTiêuToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(202, 41);
            this.hệThốngToolStripMenuItem.Text = "HỆ THỐNG";
            // 
            // tạoKhoảnChiTiêuToolStripMenuItem
            // 
            this.tạoKhoảnChiTiêuToolStripMenuItem.Name = "tạoKhoảnChiTiêuToolStripMenuItem";
            this.tạoKhoảnChiTiêuToolStripMenuItem.Size = new System.Drawing.Size(392, 46);
            this.tạoKhoảnChiTiêuToolStripMenuItem.Text = "Thêm Thu Nhập";
            this.tạoKhoảnChiTiêuToolStripMenuItem.Click += new System.EventHandler(this.tạoKhoảnChiTiêuToolStripMenuItem_Click);
            // 
            // thêmChiTiêuToolStripMenuItem
            // 
            this.thêmChiTiêuToolStripMenuItem.Name = "thêmChiTiêuToolStripMenuItem";
            this.thêmChiTiêuToolStripMenuItem.Size = new System.Drawing.Size(392, 46);
            this.thêmChiTiêuToolStripMenuItem.Text = "Thêm Chi Tiêu";
            this.thêmChiTiêuToolStripMenuItem.Click += new System.EventHandler(this.thêmChiTiêuToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.báoCáoThuChiToolStripMenuItem,
            this.biểuĐồThuChiToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(177, 41);
            this.quảnLýToolStripMenuItem.Text = "QUẢN LÝ";
            // 
            // báoCáoThuChiToolStripMenuItem
            // 
            this.báoCáoThuChiToolStripMenuItem.Name = "báoCáoThuChiToolStripMenuItem";
            this.báoCáoThuChiToolStripMenuItem.Size = new System.Drawing.Size(409, 46);
            this.báoCáoThuChiToolStripMenuItem.Text = "Báo Cáo Thu Chi";
            this.báoCáoThuChiToolStripMenuItem.Click += new System.EventHandler(this.báoCáoThuChiToolStripMenuItem_Click);
            // 
            // tHÔNGTINToolStripMenuItem
            // 
            this.tHÔNGTINToolStripMenuItem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tHÔNGTINToolStripMenuItem.Name = "tHÔNGTINToolStripMenuItem";
            this.tHÔNGTINToolStripMenuItem.Size = new System.Drawing.Size(209, 41);
            this.tHÔNGTINToolStripMenuItem.Text = "THÔNG TIN";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 45);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1494, 39);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(84, 33);
            this.toolStripButton1.Text = "Thêm";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(62, 33);
            this.toolStripButton2.Text = "Xóa";
            // 
            // biểuĐồThuChiToolStripMenuItem
            // 
            this.biểuĐồThuChiToolStripMenuItem.Name = "biểuĐồThuChiToolStripMenuItem";
            this.biểuĐồThuChiToolStripMenuItem.Size = new System.Drawing.Size(409, 46);
            this.biểuĐồThuChiToolStripMenuItem.Text = "Biểu Đồ Thu Chi";
            this.biểuĐồThuChiToolStripMenuItem.Click += new System.EventHandler(this.biểuĐồThuChiToolStripMenuItem_Click);
            // 
            // frm_HOME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 910);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm_HOME";
            this.Text = "TRANG CHỦ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tạoKhoảnChiTiêuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem thêmChiTiêuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHÔNGTINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoThuChiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biểuĐồThuChiToolStripMenuItem;
    }
}