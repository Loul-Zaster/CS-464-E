﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_HOME : Form
    {
        public frm_HOME()
        {
            InitializeComponent();
        }

        private void tạoKhoảnChiTiêuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_THUNHAP"] == null)
            {
                frm_THUNHAP frm_ADD = new frm_THUNHAP();
                frm_ADD.MdiParent = this;
                frm_ADD.Show();
            }
            else
            {
                Application.OpenForms["frm_THUNHAP"].Activate();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_THUNHAP"] == null)
            {
                frm_THUNHAP frm_ADD = new frm_THUNHAP();
                frm_ADD.MdiParent = this;
                frm_ADD.Show();
            }
            else
            {
                Application.OpenForms["frm_THUNHAP"].Activate();
            }
        }

        private void thêmChiTiêuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_CHITIEU"] == null)
            {
                frm_CHITIEU frm_ADD = new frm_CHITIEU();
                frm_ADD.MdiParent = this;
                frm_ADD.Show();
            }
            else
            {
                Application.OpenForms["frm_CHITIEU"].Activate();
            }
        }

        private void báoCáoThuChiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_BAOCAOTHUCHI"] == null)
            {
                frm_BAOCAOTHUCHI baocao = new frm_BAOCAOTHUCHI();
                baocao.MdiParent = this;
                baocao.Show();
            }
            else
            {
                Application.OpenForms["frm_BAOCAOTHUCHI"].Activate();
            }
        }

        private void biểuĐồThuChiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_CHART"] == null)
            {
                frm_CHART cHART = new frm_CHART();
                cHART.MdiParent = this;
                cHART.Show();
            }
            else
            {
                Application.OpenForms["frm_CHART"].Activate();
            }
        }
    }
}
