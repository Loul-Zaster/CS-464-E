﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_THUNHAP : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_THUNHAP()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void frm_THUNHAP_Load(object sender, EventArgs e)
        {
            HienThiThuNhap();
            // TODO: This line of code loads data into the 'dataChungDataSet.ThuNhap' table. You can move, or remove it, as needed.
            this.thuNhapTableAdapter.Fill(this.dataChungDataSet.ThuNhap);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO ThuNhap VALUES ('"+txt_money.Text+ "', Convert (datetime,'"+date_them.Text+"',103),'"+txt_note.Text+"')";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Thêm Thu nhập thành công");
            else MessageBox.Show("Thêm Thu nhập thất bại");
            HienThiThuNhap();
        }

        private void HienThiThuNhap()
        {
            string sql = "SELECT * FROM ThuNhap";
            dataGridView1.DataSource = lopchung.LoadDL(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "DELETE ThuNhap WHERE matn  = '" + txt_mgd.Text + "'";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Xoá thành công");
            else MessageBox.Show("Xoá thất bại");
            HienThiThuNhap();
        }

        private void btn_fix_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE ThuNhap SET sotien = '"+txt_money.Text+"', ngaynhan = Convert(datetime,'"+date_them.Text+"',103), ghichu = '"+txt_note.Text+"' WHERE matn = '"+txt_mgd.Text+"' ";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Sửa thành công");
            else MessageBox.Show("Sửa thất bại");
            HienThiThuNhap();
        }
    }
}
