﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_CHITIEU : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_CHITIEU()
        {
            InitializeComponent();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO DanhMuc VALUES ('" + cbb_danhmuc.Text.ToString() + "')";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Thêm Danh mục thành công");
            else MessageBox.Show("Thêm Danh mục thất bại");
            HienThiDanhMuc();
        }

        private void HienThiDanhMuc()
        {
            string sql = "SELECT * FROM DanhMuc";
            cbb_danhmuc.DataSource = lopchung.LoadDL(sql);
            cbb_danhmuc.DisplayMember = "TenDM";
            cbb_danhmuc.ValueMember = "MaDM";
            cbb_danhmuc.SelectedIndex = 0;
        }

        private void frm_CHITIEU_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataChungDataSet2.ChiTieu' table. You can move, or remove it, as needed.
            this.chiTieuTableAdapter.Fill(this.dataChungDataSet2.ChiTieu);
            // TODO: This line of code loads data into the 'dataChungDataSet1.DanhMuc' table. You can move, or remove it, as needed.
            this.danhMucTableAdapter.Fill(this.dataChungDataSet1.DanhMuc);
            HienThiDanhMuc();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            string sql = "DELETE DanhMuc WHERE TenDM  = '" + cbb_danhmuc.Text + "'";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Xoá thành công");
            else MessageBox.Show("Xoá thất bại");
            HienThiDanhMuc();
        }
        private void HienThiChiTieu()
        {
            string sql = "SELECT * FROM ChiTieu";
            dataGridView1.DataSource = lopchung.LoadDL(sql);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_luu_Click(object sender, EventArgs e)
        {
            int maDM = Convert.ToInt32(cbb_danhmuc.SelectedValue);

            string sql = "INSERT INTO ChiTieu (tenCT, soluong, sotien, MaDM, ghichu, ngaychi) " + "VALUES (N'" + txt_tenCT.Text + "', " +txt_sl.Text + ", " +txt_sotien.Text + ", " +maDM + ", " +"N'" + txt_ghichu.Text + "', Convert (datetime,'"+date_chitieu.Text+"',103)) ";
            int kq = lopchung.ThemSuaXoa(sql);

            if (kq >= 1)
                MessageBox.Show("Thêm Chi tiêu thành công!");
            else
                MessageBox.Show("Thêm Chi tiêu thất bại!");

            HienThiChiTieu();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string sql = "DELETE ChiTieu WHERE maCT  = '" + txt_mact.Text + "'";
            int kq = lopchung.ThemSuaXoa(sql);
            if (kq >= 1) MessageBox.Show("Xoá thành công");
            else MessageBox.Show("Xoá thất bại");
            HienThiChiTieu();
        }
    }
}
