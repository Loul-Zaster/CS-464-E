﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLYCHITIEU
{
    public partial class frm_BAOCAOTHUCHI : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_BAOCAOTHUCHI()
        {
            InitializeComponent();
        }

        private void frm_BAOCAOTHUCHI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataChungDataSet3.TongHop' table. You can move, or remove it, as needed.
            this.tongHopTableAdapter.Fill(this.dataChungDataSet3.TongHop);
            string del = "DELETE FROM TongHop";
            data_thuchi.DataSource = null;
            data_thuchi.DataSource = lopchung.LoadDL(del);

            string sql = @"
                                        INSERT INTO [dbo].[TongHop] (SoTien, Loai, NgayThang, GhiChu)
                                        SELECT 
                                            CAST(sotien AS NVARCHAR(50)) AS SoTien,
                                            N'Chi Tiêu' AS Loai,
                                            ngaychi AS NgayThang,
                                            ghichu AS GhiChu
                                        FROM [dbo].[ChiTieu];

                                        INSERT INTO [dbo].[TongHop] (SoTien, Loai, NgayThang, GhiChu)
                                        SELECT 
                                            CAST(sotien AS NVARCHAR(50)) AS SoTien,
                                            N'Thu Nhập' AS Loai,
                                            ngaynhan AS NgayThang,
                                            ghichu AS GhiChu
                                        FROM [dbo].[ThuNhap];
                                    ";
            data_thuchi.DataSource = lopchung.LoadDL(sql);
        }
        private void LoadDataGridView()
        {
            string sql = "SELECT SoTien, Loai, NgayThang, GhiChu FROM [dbo].[TongHop]";
            data_thuchi.DataSource = null;
            data_thuchi.DataSource = lopchung.LoadDL(sql);
            Tinhtien();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void Tinhtien()
        {
            string queryThu = "SELECT SUM(CAST(sotien AS INT)) FROM ThuNhap";
            string queryChi = "SELECT SUM(CAST(sotien AS INT)) FROM ChiTieu";

            int totalThu = lopchung.LayGT(queryThu) != DBNull.Value ? Convert.ToInt32(lopchung.LayGT(queryThu)) : 0;
            int totalChi = lopchung.LayGT(queryChi) != DBNull.Value ? Convert.ToInt32(lopchung.LayGT(queryChi)) : 0;

            // Hiển thị kết quả lên Label
            lbl_thu.Text = totalThu.ToString("N0");
            lbl_chi.Text = totalChi.ToString("N0");

        }

        private void btn_reload_Click(object sender, EventArgs e)
        {
            LoadDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (data_thuchi.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog
                {
                    Filter = "PDF (*.pdf)|*.pdf",
                    FileName = "Data.pdf"
                };

                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(save.FileName))
                    {
                        foreach (DataGridViewColumn column in data_thuchi.Columns)
                        {
                            sw.Write(column.HeaderText + "\t");
                        }
                        sw.WriteLine();

                        foreach (DataGridViewRow row in data_thuchi.Rows)
                        {
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                sw.Write((cell.Value ?? "").ToString() + "\t");
                            }
                            sw.WriteLine();
                        }
                    }

                    MessageBox.Show("Dữ liệu đã được xuất thành công!");
                }
            }
        }
    }
}
